#include <WiFiS3.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <ArduinoJson.h>
#include "arduino_secrets.h"

// ==================================================
// PRIVATE SETTINGS ARE STORED IN arduino_secrets.h
// ==================================================

const char WIFI_NAME[] = SECRET_WIFI_NAME;
const char WIFI_PASSWORD[] = SECRET_WIFI_PASSWORD;

IPAddress macAddress(SECRET_BRIDGE_IP);
const int BRIDGE_PORT = 8765;

// ==================================================
// PINS
// ==================================================

const int NEXT_BUTTON = 2;
const int PLAY_BUTTON = 3;
const int BACK_BUTTON = 4;

const int SCREEN_BL = 7;
const int SCREEN_RST = 8;
const int SCREEN_DC = 9;
const int SCREEN_CS = 10;

// Screen DIN is D11 and screen CLK is D13.
const int VOLUME_KNOB = A0;

// ==================================================
// DEVICES AND PROGRAM STATE
// ==================================================

Adafruit_ST7789 screen(SCREEN_CS, SCREEN_DC, SCREEN_RST);
WiFiClient client;

bool previousNextState = HIGH;
bool previousPlayState = HIGH;
bool previousBackState = HIGH;

unsigned long lastButtonTime = 0;
const unsigned long BUTTON_DEBOUNCE = 200;

int lastSentVolume = -1;
unsigned long previousVolumeCheck = 0;
const unsigned long VOLUME_CHECK_INTERVAL = 200;

String displayedSong = "";
String displayedArtist = "";
String displayedState = "stopped";
int displayedVolume = 0;
float displayedPosition = 0;
float displayedDuration = 0;

unsigned long previousStatusUpdate = 0;
const unsigned long STATUS_UPDATE_INTERVAL = 2000;

enum DisplayView {
  INFORMATION_VIEW,
  ARTWORK_VIEW
};

DisplayView currentView = INFORMATION_VIEW;
unsigned long viewStartTime = 0;
const unsigned long INFORMATION_VIEW_TIME = 7000;
const unsigned long ARTWORK_VIEW_TIME = 5000;

const int ARTWORK_SIZE = 220;
const int ARTWORK_X = 50;
const int ARTWORK_Y = 10;

// ==================================================
// SETUP AND LOOP
// ==================================================

void setup() {
  Serial.begin(115200);

  pinMode(NEXT_BUTTON, INPUT_PULLUP);
  pinMode(PLAY_BUTTON, INPUT_PULLUP);
  pinMode(BACK_BUTTON, INPUT_PULLUP);
  analogReadResolution(10);

  initializeScreen();
  connectToWiFi();
  requestMusicStatus();

  currentView = INFORMATION_VIEW;
  viewStartTime = millis();
}

void loop() {
  checkButtons();
  checkVolumeKnob();

  if (millis() - previousStatusUpdate >= STATUS_UPDATE_INTERVAL) {
    previousStatusUpdate = millis();
    requestMusicStatus();
  }

  updateDisplayView();
}

// ==================================================
// STARTUP
// ==================================================

void initializeScreen() {
  pinMode(SCREEN_BL, OUTPUT);
  digitalWrite(SCREEN_BL, HIGH);

  screen.init(240, 320);
  screen.setRotation(1);
  screen.setTextWrap(false);
  screen.fillScreen(ST77XX_BLACK);

  drawConnectionMessage("Starting...");
}

void connectToWiFi() {
  drawConnectionMessage("Connecting...");
  Serial.print("Connecting to Wi-Fi");

  WiFi.begin(WIFI_NAME, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("Connected to Wi-Fi!");
  Serial.print("Arduino IP address: ");
  Serial.println(WiFi.localIP());

  drawConnectionMessage("Wi-Fi connected");
  delay(800);
}

// ==================================================
// VIEW SWITCHING
// ==================================================

void updateDisplayView() {
  unsigned long timeInView = millis() - viewStartTime;

  if (currentView == INFORMATION_VIEW &&
      timeInView >= INFORMATION_VIEW_TIME) {
    currentView = ARTWORK_VIEW;
    viewStartTime = millis();
    drawArtworkScreen();
  } else if (currentView == ARTWORK_VIEW &&
             timeInView >= ARTWORK_VIEW_TIME) {
    showInformationView();
  }
}

void showInformationView() {
  currentView = INFORMATION_VIEW;
  viewStartTime = millis();
  drawNowPlayingScreen();
}

// ==================================================
// BUTTONS
// ==================================================

void checkButtons() {
  bool currentNextState = digitalRead(NEXT_BUTTON);
  bool currentPlayState = digitalRead(PLAY_BUTTON);
  bool currentBackState = digitalRead(BACK_BUTTON);

  bool debounceFinished = millis() - lastButtonTime >= BUTTON_DEBOUNCE;

  if (debounceFinished && previousNextState == HIGH && currentNextState == LOW) {
    lastButtonTime = millis();
    showInformationView();
    sendMusicCommand("next");
  }

  if (debounceFinished && previousPlayState == HIGH && currentPlayState == LOW) {
    lastButtonTime = millis();
    showInformationView();
    sendMusicCommand("playpause");
  }

  if (debounceFinished && previousBackState == HIGH && currentBackState == LOW) {
    lastButtonTime = millis();
    showInformationView();
    sendMusicCommand("previous");
  }

  previousNextState = currentNextState;
  previousPlayState = currentPlayState;
  previousBackState = currentBackState;
}

void sendMusicCommand(const char command[]) {
  Serial.print("Sending command: ");
  Serial.println(command);

  client.stop();

  if (!client.connect(macAddress, BRIDGE_PORT)) {
    Serial.println("Could not reach the Mac bridge.");
    return;
  }

  client.print("GET /command?action=");
  client.print(command);
  client.println(" HTTP/1.1");
  sendCommonHttpHeaders();

  discardBridgeResponse(1000);
  previousStatusUpdate = 0;
}

// ==================================================
// POTENTIOMETER VOLUME
// ==================================================

void checkVolumeKnob() {
  if (millis() - previousVolumeCheck < VOLUME_CHECK_INTERVAL) {
    return;
  }

  previousVolumeCheck = millis();

  long readingTotal = 0;
  for (int readingNumber = 0; readingNumber < 8; readingNumber++) {
    readingTotal += analogRead(VOLUME_KNOB);
  }

  int averageReading = readingTotal / 8;
  int newVolume = map(averageReading, 0, 1023, 0, 100);
  newVolume = constrain(newVolume, 0, 100);

  if (lastSentVolume == -1 || abs(newVolume - lastSentVolume) >= 3) {
    lastSentVolume = newVolume;
    displayedVolume = newVolume;

    Serial.print("Setting Apple Music volume to ");
    Serial.print(newVolume);
    Serial.println("%");

    showInformationView();
    sendVolumeToMac(newVolume);
  }
}

void sendVolumeToMac(int volume) {
  client.stop();

  if (!client.connect(macAddress, BRIDGE_PORT)) {
    Serial.println("Could not send the volume command.");
    return;
  }

  client.print("GET /command?action=volume&value=");
  client.print(volume);
  client.println(" HTTP/1.1");
  sendCommonHttpHeaders();

  discardBridgeResponse(1000);
}

// ==================================================
// CURRENT SONG REQUEST
// ==================================================

void requestMusicStatus() {
  client.stop();

  if (!client.connect(macAddress, BRIDGE_PORT)) {
    Serial.println("Could not reach the Mac bridge.");

    displayedSong = "";
    displayedArtist = "";
    displayedState = "stopped";
    currentView = INFORMATION_VIEW;
    drawConnectionMessage("Mac unavailable");
    return;
  }

  client.println("GET /status HTTP/1.1");
  sendCommonHttpHeaders();
  client.setTimeout(5000);

  if (!skipHttpHeaders()) {
    Serial.println("Invalid status response from bridge.");
    client.stop();
    return;
  }

  JsonDocument musicData;
  DeserializationError error = deserializeJson(musicData, client);

  if (error) {
    Serial.print("JSON error: ");
    Serial.println(error.c_str());
    client.stop();
    return;
  }

  const char* songValue = musicData["song"] | "Unknown Song";
  const char* artistValue = musicData["artist"] | "Unknown Artist";
  const char* stateValue = musicData["state"] | "stopped";

  String newSong = makeDisplaySafe(String(songValue));
  String newArtist = makeDisplaySafe(String(artistValue));
  String newState = String(stateValue);
  int newVolume = musicData["volume"] | displayedVolume;
  float newPosition = musicData["position"] | 0.0;
  float newDuration = musicData["duration"] | 0.0;

  bool songChanged = newSong != displayedSong || newArtist != displayedArtist;
  bool informationChanged = songChanged ||
                            newState != displayedState ||
                            newVolume != displayedVolume;

  displayedSong = newSong;
  displayedArtist = newArtist;
  displayedState = newState;
  displayedVolume = newVolume;
  displayedPosition = newPosition;
  displayedDuration = newDuration;

  if (songChanged) {
    showInformationView();
  } else if (currentView == INFORMATION_VIEW) {
    if (informationChanged) {
      drawNowPlayingScreen();
    } else {
      drawProgressArea();
    }
  }

  client.stop();
}

// ==================================================
// ARTWORK STREAMING
// ==================================================

void drawArtworkScreen() {
  screen.fillScreen(ST77XX_BLACK);
  screen.setTextColor(ST77XX_WHITE);
  screen.setTextSize(2);
  screen.setCursor(83, 105);
  screen.print("Loading art...");

  client.stop();

  if (!client.connect(macAddress, BRIDGE_PORT)) {
    drawArtworkError("Mac unavailable");
    return;
  }

  client.println("GET /artwork HTTP/1.1");
  sendCommonHttpHeaders();
  client.setTimeout(10000);

  String statusLine = client.readStringUntil('\n');
  bool successfulResponse = statusLine.indexOf(" 200 ") >= 0;

  while (client.connected()) {
    String headerLine = client.readStringUntil('\n');
    if (headerLine == "\r") {
      break;
    }
  }

  if (!successfulResponse) {
    client.stop();
    drawArtworkError("Artwork error");
    return;
  }

  screen.fillScreen(ST77XX_BLACK);

  uint8_t rowBytes[ARTWORK_SIZE * 2];
  uint16_t rowPixels[ARTWORK_SIZE];

  for (int row = 0; row < ARTWORK_SIZE; row++) {
    size_t bytesRead = client.readBytes(
      reinterpret_cast<char*>(rowBytes),
      sizeof(rowBytes)
    );

    if (bytesRead != sizeof(rowBytes)) {
      client.stop();
      drawArtworkError("Transfer stopped");
      return;
    }

    for (int column = 0; column < ARTWORK_SIZE; column++) {
      int byteIndex = column * 2;
      rowPixels[column] =
        (static_cast<uint16_t>(rowBytes[byteIndex]) << 8) |
        rowBytes[byteIndex + 1];
    }

    // Draw one row at a time so the whole image never occupies Arduino RAM.
    screen.drawRGBBitmap(
      ARTWORK_X,
      ARTWORK_Y + row,
      rowPixels,
      ARTWORK_SIZE,
      1
    );
  }

  client.stop();
}

void drawArtworkError(const char message[]) {
  screen.fillScreen(ST77XX_BLACK);
  screen.setTextColor(ST77XX_RED);
  screen.setTextSize(2);
  screen.setCursor(20, 105);
  screen.print(message);
}

// ==================================================
// HTTP HELPERS
// ==================================================

void sendCommonHttpHeaders() {
  client.println("Host: apple-music-bridge");
  client.println("Connection: close");
  client.println();
}

bool skipHttpHeaders() {
  String statusLine = client.readStringUntil('\n');

  if (statusLine.indexOf(" 200 ") < 0) {
    return false;
  }

  while (client.connected()) {
    String headerLine = client.readStringUntil('\n');
    if (headerLine == "\r") {
      return true;
    }
  }

  return false;
}

void discardBridgeResponse(unsigned long timeoutLength) {
  unsigned long startTime = millis();

  while (!client.available() && millis() - startTime < timeoutLength) {
    // Wait briefly for the bridge to answer.
  }

  while (client.connected() || client.available()) {
    while (client.available()) {
      client.read();
    }

    if (millis() - startTime >= timeoutLength) {
      break;
    }
  }

  client.stop();
}

// ==================================================
// INFORMATION SCREEN
// ==================================================

void drawNowPlayingScreen() {
  screen.fillScreen(ST77XX_BLACK);

  screen.setTextColor(ST77XX_MAGENTA);
  screen.setTextSize(2);
  screen.setCursor(10, 10);
  screen.print("APPLE MUSIC");

  drawVolumeValue();
  screen.drawFastHLine(10, 35, screen.width() - 20, ST77XX_MAGENTA);

  screen.setTextColor(ST77XX_CYAN);
  screen.setTextSize(1);
  screen.setCursor(10, 52);
  screen.print("NOW PLAYING");

  screen.setTextColor(ST77XX_WHITE);
  screen.setTextSize(2);
  screen.setCursor(10, 68);
  screen.print(shortenText(displayedSong, 24));

  screen.setTextColor(ST77XX_CYAN);
  screen.setTextSize(1);
  screen.setCursor(10, 108);
  screen.print("ARTIST");

  screen.setTextColor(ST77XX_WHITE);
  screen.setTextSize(2);
  screen.setCursor(10, 124);
  screen.print(shortenText(displayedArtist, 24));

  drawProgressArea();
  drawPlaybackState();
}

void drawVolumeValue() {
  screen.fillRect(235, 8, 75, 18, ST77XX_BLACK);

  String volumeText = "VOL " + String(displayedVolume) + "%";
  screen.setTextColor(ST77XX_WHITE);
  screen.setTextSize(1);

  int16_t x1;
  int16_t y1;
  uint16_t textWidth;
  uint16_t textHeight;

  screen.getTextBounds(
    volumeText,
    0,
    0,
    &x1,
    &y1,
    &textWidth,
    &textHeight
  );

  screen.setCursor(screen.width() - 10 - textWidth, 15);
  screen.print(volumeText);
}

void drawProgressArea() {
  screen.fillRect(10, 160, 300, 37, ST77XX_BLACK);

  screen.drawRect(10, 164, 300, 10, ST77XX_WHITE);

  int filledWidth = 0;
  if (displayedDuration > 0) {
    filledWidth = static_cast<int>(
      (displayedPosition / displayedDuration) * 296.0
    );
  }

  filledWidth = constrain(filledWidth, 0, 296);
  screen.fillRect(12, 166, filledWidth, 6, ST77XX_MAGENTA);

  screen.setTextColor(ST77XX_WHITE);
  screen.setTextSize(1);
  screen.setCursor(10, 183);
  screen.print(formatTime(displayedPosition));

  String durationText = formatTime(displayedDuration);
  int durationX = screen.width() - 10 - (durationText.length() * 6);
  screen.setCursor(durationX, 183);
  screen.print(durationText);
}

void drawPlaybackState() {
  screen.fillRect(10, 204, 300, 25, ST77XX_BLACK);
  screen.setTextSize(2);
  screen.setCursor(10, 207);

  if (displayedState == "playing") {
    screen.setTextColor(ST77XX_GREEN);
    screen.print("> PLAYING");
  } else if (displayedState == "paused") {
    screen.setTextColor(ST77XX_YELLOW);
    screen.print("|| PAUSED");
  } else {
    screen.setTextColor(ST77XX_RED);
    screen.print("STOPPED");
  }
}

void drawConnectionMessage(const char message[]) {
  screen.fillScreen(ST77XX_BLACK);
  screen.setTextColor(ST77XX_WHITE);
  screen.setTextSize(2);
  screen.setCursor(15, 105);
  screen.print(message);
}

// ==================================================
// TEXT HELPERS
// ==================================================

String formatTime(float secondsValue) {
  int totalSeconds = max(0, static_cast<int>(secondsValue));
  int minutes = totalSeconds / 60;
  int seconds = totalSeconds % 60;

  String result = String(minutes) + ":";
  if (seconds < 10) {
    result += "0";
  }

  result += String(seconds);
  return result;
}

String shortenText(String text, int maximumCharacters) {
  if (text.length() <= maximumCharacters) {
    return text;
  }

  String shortened = text.substring(0, maximumCharacters - 3);
  shortened += "...";
  return shortened;
}

String makeDisplaySafe(String text) {
  text.replace("\xE2\x80\x99", "'");
  text.replace("\xE2\x80\x98", "'");
  text.replace("\xE2\x80\x9C", "\"");
  text.replace("\xE2\x80\x9D", "\"");
  text.replace("\xE2\x80\x93", "-");
  text.replace("\xE2\x80\x94", "-");
  return text;
}
