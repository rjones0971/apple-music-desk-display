#ifndef ARDUINO_SECRETS_H
#define ARDUINO_SECRETS_H

// Copy this file, rename the copy to arduino_secrets.h,
// and replace these example values with your own network settings.

#define SECRET_WIFI_NAME "YOUR_WIFI_NAME"
#define SECRET_WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
#define SECRET_BRIDGE_IP 192, 168, 1, 100

#endif
