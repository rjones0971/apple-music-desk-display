# Project images

Add a clear photograph of the completed display and, if possible, a short GIF
or video demonstration. Do not add extracted album-art files or screenshots
that reveal private account or network information.
