import json
import subprocess
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from PIL import Image, ImageOps


PORT = 8765
ARTWORK_SIZE = 220
ARTWORK_FILE = Path(tempfile.gettempdir()) / "apple_music_bridge_artwork"

artwork_lock = threading.Lock()
cached_artwork_key = None
cached_artwork_bytes = None


def run_applescript(script):
    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip())

    return result.stdout.strip()


def get_music_status():
    script = '''
    tell application "Music"
        if player state is stopped then
            return "Nothing Playing" & tab & "" & tab & "0" & tab & "0" & tab & "stopped" & tab & (sound volume as string)
        end if

        set songName to name of current track
        set artistName to artist of current track
        set songPosition to player position
        set songDuration to duration of current track
        set playbackState to player state as string
        set musicVolume to sound volume

        return songName & tab & artistName & tab & songPosition & tab & songDuration & tab & playbackState & tab & musicVolume
    end tell
    '''

    result = run_applescript(script)
    parts = result.split("\t")

    if len(parts) != 6:
        raise RuntimeError("Unexpected response from Apple Music")

    return {
        "song": parts[0],
        "artist": parts[1],
        "position": float(parts[2]),
        "duration": float(parts[3]),
        "state": parts[4],
        "volume": int(parts[5]),
    }


def control_music(action, value=None):
    if action == "playpause":
        run_applescript('tell application "Music" to playpause')
    elif action == "next":
        run_applescript('tell application "Music" to next track')
    elif action == "previous":
        run_applescript('tell application "Music" to previous track')
    elif action == "volume":
        if value is None:
            raise ValueError("No volume value was provided")

        volume = max(0, min(100, int(value)))
        run_applescript(
            f'tell application "Music" to set sound volume to {volume}'
        )
    else:
        raise ValueError("Unknown command")


def extract_current_artwork():
    artwork_path = str(ARTWORK_FILE)

    script = f'''
    set outputFile to POSIX file "{artwork_path}"

    tell application "Music"
        if player state is stopped then error "Nothing is currently playing."
        if (count of artworks of current track) is 0 then error "This track has no artwork."
        set artworkData to raw data of artwork 1 of current track
    end tell

    set fileReference to open for access outputFile with write permission

    try
        set eof fileReference to 0
        write artworkData to fileReference
        close access fileReference
    on error errorMessage
        try
            close access fileReference
        end try
        error errorMessage
    end try
    '''

    run_applescript(script)

    if not ARTWORK_FILE.exists() or ARTWORK_FILE.stat().st_size == 0:
        raise RuntimeError("Apple Music did not provide artwork data")


def image_to_rgb565(image):
    square_image = ImageOps.fit(
        image.convert("RGB"),
        (ARTWORK_SIZE, ARTWORK_SIZE),
        method=Image.Resampling.LANCZOS,
    )

    output = bytearray()

    for red, green, blue in square_image.getdata():
        pixel = ((red & 0xF8) << 8) | ((green & 0xFC) << 3) | (blue >> 3)
        output.append((pixel >> 8) & 0xFF)
        output.append(pixel & 0xFF)

    return bytes(output)


def get_artwork_bytes():
    global cached_artwork_key
    global cached_artwork_bytes

    status = get_music_status()
    artwork_key = (
        status["song"],
        status["artist"],
        round(status["duration"], 2),
    )

    with artwork_lock:
        if artwork_key == cached_artwork_key and cached_artwork_bytes is not None:
            return cached_artwork_bytes

        extract_current_artwork()

        with Image.open(ARTWORK_FILE) as source_image:
            converted = image_to_rgb565(source_image)

        cached_artwork_key = artwork_key
        cached_artwork_bytes = converted
        return converted


class MusicRequestHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def send_json(self, data, status_code=200):
        response = json.dumps(data).encode("utf-8")

        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(response)
        self.close_connection = True

    def send_artwork(self, artwork):
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(artwork)))
        self.send_header("X-Artwork-Width", str(ARTWORK_SIZE))
        self.send_header("X-Artwork-Height", str(ARTWORK_SIZE))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(artwork)
        self.close_connection = True

    def do_GET(self):
        try:
            request = urlparse(self.path)
            parameters = parse_qs(request.query)

            if request.path == "/status":
                self.send_json(get_music_status())
                return

            if request.path == "/artwork":
                self.send_artwork(get_artwork_bytes())
                return

            if request.path == "/command":
                action = parameters.get("action", [None])[0]
                value = parameters.get("value", [None])[0]
                control_music(action, value)
                self.send_json({"success": True, "action": action})
                return

            self.send_json({"error": "Page not found"}, status_code=404)

        except Exception as error:
            self.send_json({"error": str(error)}, status_code=500)

    def log_message(self, format_string, *args):
        print(
            f"Request from {self.client_address[0]}: "
            f"{format_string % args}"
        )


def main():
    server = ThreadingHTTPServer(("0.0.0.0", PORT), MusicRequestHandler)

    print("Apple Music artwork bridge is running.")
    print(f"Port: {PORT}")
    print(f"Artwork size: {ARTWORK_SIZE} x {ARTWORK_SIZE}")
    print("Press Control+C to stop it.")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nBridge stopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
